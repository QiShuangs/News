package com.example.admin.myapplication11;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import org.xutils.DbManager;
import org.xutils.common.util.KeyValue;
import org.xutils.db.sqlite.WhereBuilder;
import org.xutils.ex.DbException;
import org.xutils.view.annotation.ContentView;
import org.xutils.x;
import java.io.File;
import java.util.List;
@ContentView(R.layout.activity_main)
public class MainActivity extends AppCompatActivity {
    private DbManager.DaoConfig config;
    private DbManager db;
    private ListView mLv_show;
    private List<Note> datas;
    private MyAdapter myAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
        initDB();
        mLv_show = (ListView) findViewById(R.id.lv_show);
        registerForContextMenu(mLv_show);
        try {
            datas = db.selector(Note.class).findAll();
            myAdapter = new MyAdapter(MainActivity.this,datas);
            if (datas!=null) {
                myAdapter.setDatas(datas);
            }
            mLv_show.setAdapter(myAdapter);
        } catch (DbException e) {
            e.printStackTrace();
        }
    }

    private void initDB() {
        config = new DbManager.DaoConfig();
        config.setDbName("my_note")
                .setDbDir(new File("data/data/com.example.admin.myapplication11/my_note"));
        db = x.getDb(config);
    }

    @Override
    public boolean onCreateOptionsMenu(final Menu menu) {
        getMenuInflater().inflate(R.menu.db_menu, menu);
        MenuItem item = menu.findItem(R.id.app_bar_search);
        SearchView actionView = (SearchView) item.getActionView();
        actionView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                //清空lsitview
                myAdapter.getDatas().clear();
                myAdapter.notifyDataSetChanged();
                try {
                    List<Note> notes = db.selector(Note.class).where("title", "like", "%" + newText + "%").or("text", "like", "%" + newText + "%").findAll();
                    myAdapter.setDatas(notes);
                    myAdapter.notifyDataSetChanged();
                } catch (DbException e) {
                    e.printStackTrace();
                }
                return false;
            }
        });

        return true;
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
       getMenuInflater().inflate(R.menu.context_menu,menu);
        super.onCreateContextMenu(menu, v, menuInfo);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add:
                addNote();
                break;

        }
        return true;
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ContextMenu.ContextMenuInfo menuInfo = item.getMenuInfo();
        AdapterView.AdapterContextMenuInfo adapterContextMenuInfo = (AdapterView.AdapterContextMenuInfo) menuInfo;
        int position = adapterContextMenuInfo.position;
        String title = datas.get(position).getTitle();
        String text = datas.get(position).getText();
        Note note = myAdapter.getDatas().get(position);
        switch (item.getItemId()){
            case R.id.delete_item:
                myAdapter.getDatas().remove(position);
                try {
                    db.delete(Note.class,WhereBuilder.b("title","=",title).and("text","=",text));
                } catch (DbException e) {
                    e.printStackTrace();
                }
                myAdapter.notifyDataSetChanged();
                break;
            case R.id.update_item :
                updateNote(note);
                break;
        }
        return true;
    }

    private void updateNote(final Note note) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View layout = LayoutInflater.from(this).inflate(R.layout.add_note_layout, null);
        final EditText et_title = (EditText) layout.findViewById(R.id.et_title);
        final EditText et_text = (EditText) layout.findViewById(R.id.et_text);
        //数据回显
        et_title.setText(note.getTitle());
        et_text.setText(note.getText());
        AlertDialog alertDialog = builder.setTitle("修改数据")
                .setIcon(R.mipmap.ic_launcher)
                .setView(layout)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                            Note newnote = new Note();
                            newnote.setTitle(et_title.getText().toString().trim());
                            newnote.setText(et_text.getText().toString().trim());
                            WhereBuilder b = WhereBuilder.b("title", "=",note.getTitle());
                            KeyValue kv1 = new KeyValue("title",newnote.getTitle());
                            KeyValue kv2 = new KeyValue("text",newnote.getText());
                        try {
                                db.update(Note.class,b,kv1,kv2);
                                List<Note> notes =  db.selector(Note.class).findAll();
                                myAdapter.setDatas(notes);
                                mLv_show.setAdapter(myAdapter);
                                myAdapter.notifyDataSetChanged();

                            } catch (DbException e) {
                                e.printStackTrace();
                            }
                        }

                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create();
        alertDialog.show();
    }
    private void addNote() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        View layout = LayoutInflater.from(this).inflate(R.layout.add_note_layout, null);
        final EditText et_title = (EditText) layout.findViewById(R.id.et_title);
        final EditText et_text = (EditText) layout.findViewById(R.id.et_text);
        AlertDialog alertDialog = builder.setTitle("添加数据")
                .setIcon(R.mipmap.ic_launcher)
                .setView(layout)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (TextUtils.isEmpty(et_title.getText().toString()) || TextUtils.isEmpty(et_text.getText().toString())) {
                            Toast.makeText(MainActivity.this, "你输入的标题或内容不能为空", Toast.LENGTH_SHORT).show();
                        } else {
                            Note note = new Note();
                            note.setText(et_text.getText().toString().trim());
                            note.setTitle(et_title.getText().toString().trim());
                            Toast.makeText(MainActivity.this, note.toString(), Toast.LENGTH_SHORT).show();
                            try {
                                db.save(note);
                                List<Note> notes =  db.selector(Note.class).findAll();
                                myAdapter.setDatas(notes);
                                mLv_show.setAdapter(myAdapter);
                                myAdapter.notifyDataSetChanged();

                            } catch (DbException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).create();
        alertDialog.show();
    }


}
