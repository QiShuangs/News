package com.example.admin.myapplication11;

import android.app.Application;

import org.xutils.x;

/**
 * Created by admin on 2016-12-09.
 */

public class App extends Application {
    @Override
    public void onCreate() {
        x.Ext.init(this);
        x.Ext.setDebug(true);
        super.onCreate();
    }
}
