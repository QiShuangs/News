package com.example.admin.myapplication11;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by admin on 2016-12-09.
 */

public class MyAdapter extends BaseAdapter {
    private Context context;
    private List<Note> datas;

    public MyAdapter(Context context, List<Note> datas) {
        this.context = context;
        this.datas = datas;
    }

    public List<Note> getDatas() {
        return datas;
    }

    public void setDatas(List<Note> datas) {
        this.datas = datas;
    }

    @Override
    public int getCount() {
        return datas.size();
    }

    @Override
    public Object getItem(int i) {
        return datas.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        View v = LayoutInflater.from(context).inflate(R.layout.note_lv_item, null);
        TextView tv1 = (TextView) v.findViewById(R.id.tv_1);
        TextView tv2 = (TextView) v.findViewById(R.id.tv_2);
        tv2.setText(datas.get(i).getText());
        tv1.setText(datas.get(i).getTitle());
        return v;
    }
}
