package com.example.admin.news.fragment;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.view.LayoutInflater;

import android.view.View;
import android.view.ViewGroup;
import com.example.admin.news.R;
import com.example.admin.news.adapter.MyNewsPageAdapter;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by admin on 2016-12-14.
 */

public class NewsFragmnet extends Fragment {

    private List<Fragment> newsBeanFragmnets;
    private ViewPager vp;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        vp = (ViewPager) inflater.inflate(R.layout.news_fragment_activity_main, null);
        return vp;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        newsBeanFragmnets = new ArrayList<>();
        newsBeanFragmnets.add(new NewsBeanFragmnet());
        newsBeanFragmnets.add(new NewsBeanFragmnet());
        newsBeanFragmnets.add(new NewsBeanFragmnet());
        newsBeanFragmnets.add(new NewsBeanFragmnet());
        MyNewsPageAdapter myNewsPageAdapter = new MyNewsPageAdapter(getFragmentManager(),newsBeanFragmnets);
        vp.setAdapter(myNewsPageAdapter);
    }
}
