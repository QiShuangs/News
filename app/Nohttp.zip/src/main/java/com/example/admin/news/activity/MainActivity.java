package com.example.admin.news.activity;

import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.fastjson.JSON;
import com.example.admin.news.R;
import com.example.admin.news.Utils.NewsApp;
import com.example.admin.news.Utils.NohttpInstance;
import com.yolanda.nohttp.NoHttp;
import com.yolanda.nohttp.RequestMethod;
import com.yolanda.nohttp.rest.OnResponseListener;
import com.yolanda.nohttp.rest.Request;
import com.yolanda.nohttp.rest.RequestQueue;
import com.yolanda.nohttp.rest.Response;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    @BindView(R.id.activity_main)
    RelativeLayout activityMain;
    @BindView(R.id.tv_show)
    TextView tvShow;
    @BindView(R.id.iv_show)
    ImageView ivShow;
    private String url = "http://v.juhe.cn/toutiao/index?type=top&key=9398ab53c96408b94f9def1a4a1cc5e6";
    private String imgurl = "http://b.hiphotos.baidu.com/image/pic/item/8d5494eef01f3a29b41f18fa9c25bc315c607c2b.jpg";
    private RequestQueue requestQueue;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        requestQueue = NohttpInstance.getInstance();
        getStringJson();
        getBitmapJson();
    }

    private void getStringJson() {
        Request<String> request = NoHttp.createStringRequest(url, RequestMethod.GET);
        requestQueue.add(0, request, new OnResponseListener<String>() {
            @Override
            public void onStart(int what) {
            }

            @Override
            public void onSucceed(int what, Response<String> response) {
                if(what==0) {
                    String result = response.get();
                    NewsApp newsApp = JSON.parseObject(result, NewsApp.class);
                    Toast.makeText(MainActivity.this, newsApp.getResult().getData().get(2).getTitle(), Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailed(int what, Response<String> response) {
            }

            @Override
            public void onFinish(int what) {
            }
        });
    }

    private void getBitmapJson() {
        Request<Bitmap> imageRequest = NoHttp.createImageRequest(imgurl, RequestMethod.GET);
        requestQueue.add(1, imageRequest, new OnResponseListener<Bitmap>() {
            @Override
            public void onStart(int what) {

            }

            @Override
            public void onSucceed(int what, Response<Bitmap> response) {
                if(what==1) {
                    ivShow.setImageBitmap(response.get());
                }
            }

            @Override
            public void onFailed(int what, Response<Bitmap> response) {

            }

            @Override
            public void onFinish(int what) {

            }
        });
    }
}
